import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";

import App from "./App";
import { createStore, combineReducers, applyMiddleware } from "redux";
import { reducer as formReducer } from "redux-form";
import { createLogger } from "redux-logger";
import { composeWithDevTools } from "redux-devtools-extension";

const initReducer = (state = { hello: "world" }, action) => {
  return state;
};

const logger = createLogger();
const rootReducer = combineReducers({
  form: formReducer,
  init: initReducer
});

export const store = createStore(
    rootReducer,
    composeWithDevTools()
  //  applyMiddleware(logger)
  );

  // store.subscribe((state) => state);
const rootElement = document.getElementById("root");

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  rootElement
);
