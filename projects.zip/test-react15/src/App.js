import React from "react";
import "./styles.css";
import { Field, reduxForm, initialize, FieldArray } from "redux-form";
import { connect } from "react-redux";
import { store } from "./index";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { items: null };
    console.log("this.props", this.props);
  }
  async componentDidMount() {
    let items = await fetch(
      "https://gist.githubusercontent.com/yozhikvtumane/9ef9833ec65516c8cea405adb0378fd1/raw/e9073e8a1610708e8ed82644289b9639ef142d97/settingsItems.json"
    );

    let itemsData = await items.json();
    console.log('itemsData', itemsData)

    // this.setState({ items: itemsData });
    this.props.dispatch(initialize("testForm", itemsData));
  }
  
  submitForm = (data) => {
    console.log('data', data)
  }
  
  render() {
    const {handleSubmit} = this.props;
    return (
      <div className="App">
        <h1>Hello CodeSandbox</h1>
        <h2>Start editing to see some magic happen!</h2>
        <form onSubmit={handleSubmit(this.submitForm)}>
          <button onClick={()=> {
            
          }}>Select all</button>
          <ul>
            <li>
              <label htmlFor="port">port</label>
              <Field name="settingsItems[0].port" component="input" type="checkbox"/>
            </li>
            <li>
              <label htmlFor="sensor">sensor</label>
              <Field name="settingsItems[1].sensor" component="input" type="checkbox"/>
            </li>
            <li>
              <label htmlFor="circuit">circuit</label>
              <Field name="settingsItems[2].circuit" component="input" type="checkbox"/>
            </li>
            <li>
              <ul>
                <li>
                  <label htmlFor="bluetooth">bluetooth</label>
                  <Field name="settingsItems[3].bluetooth" component="input" type="checkbox"/>
                </li>
              </ul>
            </li>
            <li>
              <label htmlFor="driver">driver</label>
              <Field name="settingsItems[4].driver" component="input" type="checkbox"/>
            </li>
            <li>
              <label htmlFor="panel">panel</label>
              <Field name="settingsItems[5].panel" component="input" type="checkbox"/>
            </li>
          </ul>
          <input type="submit"/>
        </form>
        
        <pre>{JSON.stringify(store.getState(), null, 2)}</pre>

        <pre>{JSON.stringify(this.state.items, null, 2)}</pre>
      </div>
    );
  }
}

App = reduxForm({
  form: "testForm",
  enableReinitialize: true
})(App);

export default connect((state) => {
  // return { initialValues: state.form.testForm.initial };
})(App);
