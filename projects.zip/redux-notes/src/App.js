import React from 'react';
import { useSelector } from 'react-redux';
import NewNote from './components/NewNote';
import Notes from './components/Notes';
import VisibilityFilter from './components/VisibilityFilter';
import notesApi from './api/notesApi'; 
import {useQuery} from 'react-query'; 
import { ReactQueryDevtools } from "react-query-devtools";


const App = (props) => {
	const notes = useQuery('notesAll', notesApi.getAll().then(res=>res));
	const {isLoading, error, data} = useQuery('notesAll', () => notesApi.getAll().then(res=>res));
	console.log('notes', notes)
	console.log('props :>> ', props);
	const storeNow = useSelector(state => state);	
	if (isLoading) return "Loading...";
	if (error) return "Error " + error.message;
	return (
		<>
			<div>
				<h1>{props.title}</h1>
			</div>
			<div>
				<h3>Store:</h3>
				<pre>
					{`{draft: '${JSON.stringify(storeNow.draft)}'}`}
				</pre>
			</div>
			<NewNote />
			<VisibilityFilter />
			{data.data.map(note => (<><span>{note.id}</span><br/></>))}
			{/* <Notes /> */}
			{/* <button onClick={() => notesApi.getAll().then(res => console.log('res', res))}>test api</button> */}
			<ReactQueryDevtools />
		</>
	);
}

export default App;
