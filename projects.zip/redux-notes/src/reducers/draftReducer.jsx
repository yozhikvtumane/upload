let initialState = {
	importance: false,
	text: ''
}

const draftReducer = (state = initialState, action) => {
	const {payload} = action;
	const {importance, text} = state;
	
	switch (action.type) {
		case 'DRAFT_CLEAN':
			return {
				importance: false,
				text: ''
			}
		
		case 'DRAFT_TEXT':
			return  {
				importance,
				text: payload
			}
		
		case 'DRAFT_IMPORTANCE':
			return {
				importance: payload,
				text 
			}
			
		default:
			return state
	}
}

export default draftReducer;