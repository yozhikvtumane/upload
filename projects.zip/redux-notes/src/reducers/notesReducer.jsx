
const notesReducer = (state = [], action) => {
	const {payload} = action;
	
	switch (action.type) {
		case 'NOTE_CREATE':
			return [
				...state,
				{
					id: payload.id,
					content: payload.content,
					important: payload.important
				}
			]
		case 'INIT_NOTES':
			return action.data
		default:
			return state
	}
}

export default notesReducer;