import React from 'react';
import { useSelector } from 'react-redux';

const Notes = () => {
	const notes = useSelector(state => {
		if (state.filter === 'ALL') {
			return state.notes
		}
		
		return state.filter === 'IMPORTANT' ?
			state.notes.filter(note => note.important):
			state.notes.filter(note => !note.important)
		
	});
	// console.log('storeNow from Notes', storeNow)
	return(
		<>
			<h3>Notes:</h3>
			<ul>
				{notes.map((note) => {
					return (
						<li key={note.id}>
							<h4>
								Note id {note.id}
								{note.important ? <span className="badge-important">important</span> : null}
							</h4>
							{note.content}
							{/* <input
								type="checkbox"
								disabled
								checked={note.important}
							/> */}
						</li>
					)
				})}
			</ul>
		</>
	)
}

export default Notes;