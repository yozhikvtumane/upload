import React from 'react';
import { useDispatch } from 'react-redux';
import * as notesActions from '../actions/notesActions';


const VisibilityFilter = () => {
	const dispatch = useDispatch();
	
	const toggleFilter = (filter) => {
		dispatch(notesActions.filterNotes(filter));
	}
	
	return (
		<>
			<h3>Filter notes by importance</h3>
			<input
				type="radio"
				name="filter"
				id="filterAll"
				onChange={() => toggleFilter('ALL')}
			/>
			<label htmlFor="filterAll">All</label>
			<br/>
			<input
				type="radio"
				name="filter"
				id="filterImportant"
				onChange={() => toggleFilter('IMPORTANT')}
			/>
			<label htmlFor="filterImportant">Important</label>
			<br/>
			<input
				type="radio"
				name="filter"
				id="notImportant"
				onChange={() => toggleFilter('NOT_IMPORTANT')}
			/>
			<label htmlFor="notImportant">Not important</label>
		</>
	)
	
}

export default VisibilityFilter;