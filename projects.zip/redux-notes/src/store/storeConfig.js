import { createStore, combineReducers } from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension';
import draftReducer from '../reducers/draftReducer';
import notesReducer from '../reducers/notesReducer';
import filterReducer from '../reducers/filterReducer';

const rootReducer = combineReducers({
	draft: draftReducer,
	filter: filterReducer,
	notes: notesReducer
});


const store = createStore(
	rootReducer,
	composeWithDevTools()
);

// store.subscribe(() => {
// 	const storeNow = store.getState();
// 	console.log('storeNow from storeConfig :>> ', storeNow);
// });

console.log('store state', store.getState());

export default store;
