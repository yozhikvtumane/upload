TODO anecdotes fullstackopen:

# ctrl+shift+u
# ⚪ u+26aa
# ⚫ u+26ab

ESTIMATED - 2h (started 13:10)

⚪ Check all exercises from the begining
⚪ Add Blueprint
⚪ Add redux-form for new anecdote
⚪ onSubmit and onSubmitSuccess - how do they work in between


