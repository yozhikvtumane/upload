import { createStore, combineReducers } from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension';
// import draftReducer from '../reducers/draftReducer';
// import notesReducer from '../reducers/notesReducer';
// import filterReducer from '../reducers/filterReducer';
import anecdoteReducer from '../reducers/anecdoteReducer';
import dialogReducer from '../reducers/dialogReducer';
import { reducer as formReducer } from 'redux-form';

const rootReducer = combineReducers({
	anecdotes: anecdoteReducer,
	dialog: dialogReducer,
	form: formReducer,
	// draft: draftReducer,
	// filter: filterReducer,
	// notes: notesReducer
});


const store = createStore(
	rootReducer,
	composeWithDevTools()
);

// store.subscribe(() => {
// 	const storeNow = store.getState();
// 	console.log('storeNow from storeConfig :>> ', storeNow);
// });

console.log('store state', store.getState());

export default store;
