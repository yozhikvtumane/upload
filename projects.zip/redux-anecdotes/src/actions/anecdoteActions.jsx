export const createNew = (anecdoteData) => {
	return {
		type: 'NEW_ANECDOTE',
		payload: {
			content: anecdoteData
		}
	}
}

export const vote = (anecdoteId) => {
	return {
		type: 'VOTE',
		payload: anecdoteId
	}
}

export const dialogToggle = () => {
	return {
		type: 'DIALOG_TOGGLE'
	}	
}