import React from 'react';
import { useDispatch } from 'react-redux';
import * as anecdoteActions from '../actions/anecdoteActions';
import { TextArea, Intent, Button } from '@blueprintjs/core';
import { reduxForm, Field } from 'redux-form';

// This form uses redux-form package to connect form to redux store

// function for form validation, passed in reduxForm config
const validate = (values) => {
	let errors = {};
	if (!values.anecdoteText) errors.anecdoteText = 'Required'
	
	return errors;
}

const CustomTextArea = (props) => {
	
	// input and meta are passed from reduxForm
	const {input: {value, onChange}, meta: {error, touched}, ...otherProps} = props;
	
	return <>
			<TextArea
				value={value}
				onChange={onChange}
				{...otherProps}
			/>
			{touched && error && <span className={'text-danger'}>{error}</span>}
		   </> 
}

// reduxForm( redux-form config: Object {formName: Required} )( component: Function )
const AnecdoteForm = reduxForm({ form: 'anecdoteForm', validate })( (props) => {
	const {handleSubmit, submitting, errors} = props;
	const dispatch = useDispatch();
	
	return <form onSubmit={handleSubmit}>
				<div className="row p-3">
					<div className="col">
						<Field
							name='anecdoteText'
							component={CustomTextArea}
							type="text"
							props={{
								growVertically: true,
								large: true,
								intent: Intent.PRIMARY,
								className: 'bp3-fill',
								errors
							}}
						/>
					</div>
				</div>
				<div className="row p-3">
					<div className="col">
						{/* in this case redux-form handles dispatch by itself after the function passed in onSubmit prop is executed */}
						<Button type="submit" disabled={submitting} intent={Intent.PRIMARY} className={'mr-1'}>Save</Button>
						<Button type="button" onClick={() => dispatch(anecdoteActions.dialogToggle())}>Cancel</Button>
					</div>
				</div>
			</form>

});
	
export default AnecdoteForm;