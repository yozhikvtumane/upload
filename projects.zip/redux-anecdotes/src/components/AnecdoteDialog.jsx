import React from 'react';
import { Dialog, Button, Classes, H3 } from '@blueprintjs/core';
import AnecdoteForm from './AnecdoteForm';
import { useSelector } from 'react-redux';
import { dialogToggle, createNew} from '../actions/anecdoteActions';
import { useDispatch } from 'react-redux';


const AnecdoteDialog = () => {
	const dispatch = useDispatch();
	const { isDialogOpen } = useSelector(state => state.dialog);
	const handleSubmit = (formData) => {
		// e.preventDefault()
		console.log('%cformData', 'font-size:32px;color:red;',formData)
		dispatch(createNew(formData.anecdoteText));
		dispatch(dialogToggle());
	}
	return (
		<Dialog
			classname={'bp3-dark'}
			isOpen={isDialogOpen}
			canOutsideClickClose={true}
			canEscapeKeyClose
			usePortal
			onClose={() => dispatch(dialogToggle())}
			portalClassName={'bp3-dark'}>
				<div className={Classes.DIALOG_HEADER}>
					<H3 className={'m-0'}>New Anecdote</H3>
				</div>
				<AnecdoteForm onSubmit={handleSubmit} onSubmitSuccess={(res)=> console.log('res', res)}/>
		</Dialog>
	)
}

export default AnecdoteDialog;