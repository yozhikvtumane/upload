import React from 'react';
import { Button, Intent } from '@blueprintjs/core';
import AnecdoteDialog from './AnecdoteDialog';
import { dialogToggle} from '../actions/anecdoteActions';
import { useDispatch } from 'react-redux';

const NewAnecdote = () => {
	const dispatch = useDispatch();
	
	return (
		<div className="row my-5">
			<div className="col d-flex justify-content-center">
				<Button 
					large
					intent={Intent.SUCCESS}
					icon={'add'}
					onClick={() => dispatch(dialogToggle())}>
						Add new anecdote
				</Button>
				<AnecdoteDialog />
			</div>
		</div>
	)
}

export default NewAnecdote;