import React from 'react';
import { H1 } from '@blueprintjs/core';

const AnecdoteHeader = () => {
	return <div className={'row'}>
				<div className="col">
					<H1 className={'text-center'}>Anecdotes 😂</H1>
				</div>
			</div>
}


export default AnecdoteHeader;