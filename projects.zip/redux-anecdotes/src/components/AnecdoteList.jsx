import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import * as anecdoteActions from '../actions/anecdoteActions';
import {Card, Button, Elevation, H3, H2, Intent, H4} from '@blueprintjs/core';


const AnecdoteList = () => {
	const anecdotes = useSelector(state => state.anecdotes);
	const dispatch = useDispatch();
	const vote = (id) => dispatch(anecdoteActions.vote(id));
	
	return (
		<>
			{anecdotes.map(anecdote =>
				<Card className={'mb-3'} key={anecdote.id} elevation={Elevation.TWO}>
					<div className="row d-flex align-items-center">
						<div className="col col-1 d-flex flex-column justify-content-center">
							<H4 className={'votes text-center'}>{anecdote.votes}</H4>
							<Button intent={Intent.SUCCESS} icon={'thumbs-up'} onClick={() => vote(anecdote.id)} />
						</div>
						<div className="col col-11 d-flex align-items-center">
							<H3 className={'m-0'}>{anecdote.content}</H3>
						</div>
					</div>
				</Card>
			)}
		</>
	)
}

export default AnecdoteList;