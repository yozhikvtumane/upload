import React, { useState } from 'react'
import AnecdoteList from './components/AnecdoteList';
import AnecdoteForm from './components/AnecdoteForm';
import { H2, H1, Button, Intent, Dialog } from '@blueprintjs/core';
import AnecdoteHeader from './components/AnecdoteHeader';
import NewAnecdote from './components/NewAnecdote';

const App = () => {
	return (
		<div className={'bp3-dark container-fluid xl-6 col-lg-9 col-md-9 py-5'}>
			<AnecdoteHeader />
			<NewAnecdote />
			{/* <AnecdoteForm /> */}
			<AnecdoteList />
		</div>
	)
}

export default App
